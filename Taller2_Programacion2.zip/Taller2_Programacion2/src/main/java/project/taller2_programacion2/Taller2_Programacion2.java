/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.taller2_programacion2;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Taller2_Programacion2 {

   public static void main(String[] args) {
      System.out.println("Ejercicio 1:");
       Ejercicio1();
       System.out.println();
      System.out.println("Ejercicio 2:");
       Ejercicio2();
       System.out.println();
      System.out.println("Ejercicio 3:");
       Ejercicio3();
       System.out.println();
      System.out.println("Ejercicio 4:");
       Ejercicio4();
       System.out.println();
      System.out.println("Ejercicio 5:");
       Ejercicio5();
       System.out.println();
      System.out.println("Ejercicio 6:");
       Ejercicio6();
       System.out.println();
      System.out.println("Ejercicio 7:");
       Ejercicio7();
       System.out.println();
      System.out.println("Ejercicio 8:");
       Ejercicio8();
       System.out.println();
       System.out.println("Ejercicio 9:");
       Ejercicio9();
       System.out.println();
       System.out.println("Ejercicio 10:");
       Ejercicio10();
       System.out.println();
       System.out.println("Ejercicio 11:");
       Ejercicio11();
       System.out.println();
       System.out.println("Ejercicio 12:");
       Ejercicio12();
       System.out.println();
       System.out.println("Ejercicio 13:");
       Ejercicio13();
       System.out.println();
       System.out.println("Ejercicio 14:");
       Ejercicio14();
       System.out.println();
       System.out.println("Ejercicio 15:");
       Ejercicio15();
       System.out.println();
       System.out.println("Ejercicio 16:");
       Ejercicio16();
       System.out.println();
       System.out.println("Ejercicio 17:");
       Ejercicio17();
       System.out.println();
       System.out.println("Ejercicio 18:");
       Ejercicio18();
       System.out.println();
       System.out.println("Ejercicio 19:");
       Ejercicio19();
       System.out.println();
       System.out.println("Ejercicio 20:");
       Ejercicio20();   
    }
   
   public static void Ejercicio1(){
     Scanner teclado = new Scanner(System.in);
    String nombre;
    System.out.println("Hola usuario, digame su nombre");
    nombre=teclado.nextLine();
    System.out.println("Hola "+ nombre);
  }
   public static void Ejercicio2(){
       Scanner teclado = new Scanner(System.in);
       System.out.print("Ingresa la base: ");
        double base = teclado.nextDouble();

        System.out.print("Ingresa la altura: ");
        double altura = teclado.nextDouble();

        double area = base * altura;
        double perimetro = 2 * (base + altura);

        System.out.println("El área del rectángulo es: " + area);
        System.out.println("El perímetro del rectángulo es: " + perimetro);
  }
   public static void Ejercicio3(){
  Scanner teclado = new Scanner(System.in);
   System.out.print("Ingresa la longitud del primer cateto: ");
        double cateto1 = teclado.nextDouble();

        System.out.print("Ingresa la longitud del segundo cateto: ");
        double cateto2 = teclado.nextDouble();

        double hipotenusa = Math.sqrt(Math.pow(cateto1, 2) + Math.pow(cateto2, 2));

        System.out.println("La longitud de la hipotenusa es: " + hipotenusa);       
  }
   public static void Ejercicio4(){
  Scanner teclado = new Scanner(System.in);
   System.out.print("Ingresa el primer número: ");
        double numA = teclado.nextDouble();

        System.out.print("Ingresa el segundo número: ");
        double numB = teclado.nextDouble();

        double suma = numA + numB;
        double resta = numA - numB;
        double division = numA / numB;
        double multiplicacion = numA * numB;

        
        System.out.println("La resta de los números es: " + resta);
        System.out.println("La suma de los números es: " + suma);
        System.out.println("La división de los números es: " + division);
        System.out.println("La multiplicación de los números es: " + multiplicacion); 
  }
   public static void Ejercicio5(){
     Scanner teclado = new Scanner(System.in);
        double fahrenheit, celsius;
        
        System.out.print("Ingrese los grados Fahrenheit: ");
        fahrenheit = teclado.nextDouble();
        
        celsius = (fahrenheit - 32) * 5/9;
        System.out.println(fahrenheit + " grados Fahrenheit es igual a " + celsius + " grados Celsius.");   
  }
   public static void Ejercicio6(){
      Scanner teclado = new Scanner(System.in);
   System.out.print("Introduce el primer número: ");
        double numA = teclado.nextDouble();
        System.out.print("Introduce el segundo número: ");
        double numB = teclado.nextDouble();
        System.out.print("Introduce el tercer número: ");
        double numC = teclado.nextDouble();
        
        double media = (numA+numB+numC)/3;
        
        System.out.println("La media de sus numeros es: "+ media);    
  }
   public static void Ejercicio7(){
         Scanner teclado = new Scanner(System.in);
    System.out.print("Ingresa la cantidad de minutos: ");
        int minutos = teclado.nextInt();
       
        int horas = minutos / 60;
        int minutosRestantes = minutos % 60;
       
        System.out.println(minutos + " minutos equivale a " + horas + " horas y " + minutosRestantes + " minutos.");    
  }
   public static void Ejercicio8(){
     Scanner sc = new Scanner(System.in);
     System.out.println("sueldo base: ");
    double salarioRegular = sc.nextDouble();
      
        System.out.print("venta 1: ");
        double venta1 = sc.nextDouble();
        System.out.print("venta 2: ");
        double venta2 = sc.nextDouble();
        System.out.print("venta 3: ");
        double venta3 = sc.nextDouble();
        
        
        double comision = (venta1 + venta2 + venta3) * 0.1;
        double totalIngresos = salarioRegular + comision;
        
        
        System.out.println("El vendedor recibirá " + comision + " de comision");
        System.out.println("El total del sueldo sera: " + totalIngresos + ".");  
   }
   public static void Ejercicio9(){
        Scanner sc = new Scanner(System.in);
        
        // Solicitar el precio total de la compra al usuario
        System.out.print("Introduce el precio de la compra: ");
        double precio = sc.nextDouble();
        
        // Calcular el descuento y el precio final
        double descuento = precio * 0.15;
        double precioFinal = precio - descuento;
        
        // Mostrar el precio final por pantalla
        System.out.println("El precio final es de:" + precioFinal);
   }
   public static void Ejercicio10(){
       Scanner sc= new Scanner(System.in);
       float parcial1,parcial2,parcial3,promedioParciales,examenFinal,TrabajoFinal;
       
       System.out.println("Digite la calificacion de su parcial 1");
       parcial1=sc.nextFloat();
       System.out.println("Digite la calificacion de su parcial 2");
       parcial2=sc.nextFloat();
       System.out.println("Digite la calificacion de su parcial 3");
       parcial3=sc.nextFloat();
       System.out.println("Digite la calificacion de su examen Final");
       examenFinal=sc.nextFloat();
       System.out.println("Digite la calificacion de su trabajo Final");
       TrabajoFinal=sc.nextFloat();
       promedioParciales=(float)(((parcial1+parcial2+parcial3)/3)*0.55);
       
       examenFinal= (float) (examenFinal*0.30);
       TrabajoFinal= (float) (TrabajoFinal*0.15);
       float total= promedioParciales+examenFinal+TrabajoFinal;
       System.out.println("El acumulado en examenes parciales es: "+ promedioParciales+ "El ponderado de tu examen final es:"+ examenFinal+ "Y el ponderado de tu trabajo final es:" + TrabajoFinal+ "Para un total de: "+ total);
       
       
   }
   public static void Ejercicio11(){
       Scanner sc = new Scanner(System.in);
        
      
        System.out.print("primer número: ");
        double num1 = sc.nextDouble();
        System.out.print("segundo número: ");
        double num2 = sc.nextDouble();
        
      
        double distancia = Math.abs(num1 - num2);
        
        
        System.out.println("distancia entre " + num1 + " y " + num2 + " es " + distancia + ".");   
       
       
   }
   public static void Ejercicio12(){
        Scanner sc = new Scanner(System.in);
        
        System.out.print("x1: ");
        double x1 = sc.nextDouble();
        System.out.print("y1: ");
        double y1 = sc.nextDouble();
        System.out.print("x2: ");
        double x2 = sc.nextDouble();
        System.out.print("y2: ");
        double y2 = sc.nextDouble();
        
        double distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        
        System.out.println("La distancia entre(" + x1 + ", " + y1 + ") y (" + x2 + ", " + y2 + ") es " + distancia);
   }
   public static void Ejercicio13(){
        Scanner sc = new Scanner(System.in);
      
        System.out.print("Introduce el número: ");
        double num = sc.nextDouble();
        
        double raizCuadrada = Math.sqrt(num);
        double raizCubica = Math.cbrt(num);
        
        System.out.println("La raíz cuadrada es:" + raizCuadrada);
        System.out.println("La raíz cúbica es " + raizCubica);
    
   }
   public static void Ejercicio14(){
   Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce un número de dos cifras: ");
        int num = sc.nextInt();
        
        int unidades = num % 10;
        int decenas = num / 10;
        
        int numInvertido = (unidades * 10) + decenas;
        
        System.out.println("El número invertido es: " + numInvertido);
    }
   public static void Ejercicio15(){
        Scanner sc = new Scanner(System.in);
        System.out.print("valor de numA: ");
        int numA = sc.nextInt();
        System.out.print("valor de NumB: ");
        int NumB = sc.nextInt();

        int numMix = numA;
        numA = NumB;
        NumB = numMix;

        // Mostrar los valores finales de numA y NumB
        System.out.println("numA es: " + numA);
        System.out.println("NumB es: " + NumB);
    }
   public static void Ejercicio16(){
        Scanner sc = new Scanner(System.in);
        System.out.print("distancia entre los dos carros: ");
        double x = sc.nextDouble();
        System.out.print("velocidad del carro que está atras: ");
        double velocidadCarro1 = sc.nextDouble();
        System.out.print("velocidad del carro que está adelante (km/h): ");
        double VelocidadCarro2 = sc.nextDouble();
        double tiempoEnHoras = x / (VelocidadCarro2 - velocidadCarro1);
        double tiempoEnMinutos = tiempoEnHoras * 60;

        System.out.println("El carro más rápido alcanzará al otro en " + tiempoEnMinutos + " minutos.");
   }
   public static void Ejercicio17(){
        Scanner sc = new Scanner(System.in);
        System.out.print(" hora de partida:");
        String inicioCiclista = sc.nextLine();

        // Pedir al usuario que ingrese el tiempo de viaje en s.
        System.out.print("tiempo de viaje en s: ");
        int t = sc.nextInt();

        // Convertir la hora de partida a s.
        String[] xhora = inicioCiclista.split(":");
        int horaSec = Integer.parseInt(xhora[0]) * 3600;
        int minSec = Integer.parseInt(xhora[1]) * 60;
        int s = Integer.parseInt(xhora[2]);
        int partida = horaSec + minSec + s;

        // Calcular la hora de llegada en s.
        int secllegada = partida + t;

        // Convertir la hora de llegada de s a horas, minutos y s.
        int horas = secllegada / 3600;
        int minutos = (secllegada % 3600) / 60;
        int sRestantes = secllegada % 60;

        // Mostrar la hora de llegada al usuario.
        System.out.printf("llega a la ciudad B a las: ", horas, minutos, sRestantes);
   }
   public static void Ejercicio18(){
      Scanner sc = new Scanner(System.in);
      String nombre1,nombre2,apellido;
      System.out.println("Digame su primer nombre");
      nombre1=sc.nextLine();
      System.out.println("Digame su segundo nombre");
      nombre2=sc.nextLine();
      System.out.println("Digame su Apellido");
      apellido= sc.nextLine();
      
      char n1,n2,ap;
      
      n1= nombre1.charAt(0);
      n2=nombre2.charAt(0);
      ap=apellido.charAt(0);
      
      System.out.println("Sus iniciales son: "+ n1+ n2+ ap);
      
   }
   public static void Ejercicio19(){
       Scanner sc = new Scanner(System.in);
       float correctas,incorrectas,noContestadas,total;
       System.out.println("Numero de correctas: ");
       correctas = sc.nextFloat();
       System.out.println("Numero de incorrectas: ");
       incorrectas = sc.nextFloat();
       System.out.println("Numero de No contestadas: ");
       noContestadas = sc.nextFloat();
       
       total = (correctas*5)-incorrectas;
       System.out.println("El total de puntos es: "+ total);
       

   }
   public static void Ejercicio20(){
        Scanner entrada = new Scanner(System.in);
        System.out.print("monedas de 2 euros: ");
        int dosEuros = entrada.nextInt();
        System.out.print("monedas de 1 euro: ");
        int unEuro = entrada.nextInt();
        System.out.print("monedas de 50 centimos: ");
        int cincuentaCentimos = entrada.nextInt();
        System.out.print("monedas de 20 centimos: ");
        int VeinteCentimos = entrada.nextInt();
        System.out.print("monedas de 10 centimos: ");
        int diezCentimos = entrada.nextInt();

        int euros = dosEuros * 2 + unEuro * 1 + cincuentaCentimos / 2 + VeinteCentimos / 5 + diezCentimos / 10;
        int centimos = (cincuentaCentimos % 2) * 50 + (VeinteCentimos % 5) * 20 + (diezCentimos % 10) * 10;

        System.out.printf("Tienes un total de %d euros y %d centimos.", euros, centimos);
   }
}
